#Creating the space folder
mkdir space

#Inside space folder
cd space

#Creating the files inside space
touch moons
touch planets

#Writing in the planets file
echo "Mercury
Venus
Earth
Mars
Jupiter
Saturn
Uranus
Neptune" > planets
mkdir missions
touch stars
touch galaxies

#Inside missions folder
cd missions
mkdir cassini
cd cassini
touch huygens.data

#Written from Exercise2.2.sh
.
drwxrwxrwx 15 robert robert 4096 sep 25 20:27 .
drwxrwxrwx 15 robert robert 4,0K sep 25 20:27 .
1069546 drwxrwxrwx 15 robert robert 4,0K sep 25 20:27 .
1069546 .
