#Using the operator >> to concatenate every command
ls -d >> Exercise2.1.sh
ls -dl >> Exercise2.1.sh
ls -dlh >> Exercise2.1.sh
ls -dlhi >> Exercise2.1.sh
ls -dhia >> Exercise2.1.sh
