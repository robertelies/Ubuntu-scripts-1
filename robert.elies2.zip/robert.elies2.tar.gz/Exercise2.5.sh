#Store file paths
origin_file="$1"
destination_file="$2"

rsync --checksum "$origin_file" "$destination_file"

#MD5 checksum of the origin file
origin_checksum=$(md5sum "$origin_file" | awk '{print $1}')

#MD5 checksum of the destination file
destination_checksum=$(md5sum "$destination_file" | awk '{print $1}')

# Printing the checksums
echo "MD5 checksum of origin file: $origin_checksum"
echo "MD5 checksum of destination file: $destination_checksum"

