#Store the filename
filename="$1"

# Get file information
access_date=$(date -r "$filename" +"%Y-%m-%d %H:%M:%S")
file_size=$(du -h "$filename" | cut -f1)
file_owner=$(stat -c "%U" "$filename")
file_type=$(file -b "$filename")

# Print info
echo "File Information for $filename:"
echo "Last Access Date: $access_date"
echo "File Size: $file_size"
echo "File Owner: $file_owner"
echo "File Type: $file_type"
