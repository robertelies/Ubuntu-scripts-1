# Get the current state of processes and write it to huygens.data
ps aux > huygens.data

# Printing first and last line
head -n 1 huygens.data
tail -n 1 huygens.data
