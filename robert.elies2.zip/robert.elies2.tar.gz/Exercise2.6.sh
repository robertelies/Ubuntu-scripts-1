unique_users=$(ps -eo user= | sort | uniq | wc -l)

echo "Number real users: $unique_users"
