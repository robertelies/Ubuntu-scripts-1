# Store the provided start and end line integers
start_line="$1"
end_line="$2"

# Use the 'dmesg' command to retrieve the kernel log
# Pipe the output to 'sed' to print lines from start_line to end_line
dmesg | sed -n "${start_line},${end_line}p"
