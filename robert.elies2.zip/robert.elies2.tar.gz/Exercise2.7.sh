file_extension="$1"

# Use the 'find' command to search for files with the specified extension in all the system
# Count the number of matching files using 'wc'
file_count=$(find / -type f -name "*.$file_extension" 2>/dev/null | wc -l)
echo "Number of .$file_extension files in the system: $file_count"
